// Advanced Widgets
console.log('🧩 Advanced Widgets loaded');