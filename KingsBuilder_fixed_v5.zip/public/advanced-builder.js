// advanced-builder.js stub
// Provided by AI fix to satisfy script reference
window.KingsBuilder = window.KingsBuilder || {};
console.log('advanced-builder.js stub loaded - KingsBuilder global created');
