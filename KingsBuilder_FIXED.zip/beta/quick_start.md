# KingsBuilder Quick Start Guide

## Getting Started
1. Install app from Shopify admin
2. Complete initial setup
3. Create your first page
4. Publish to your store

## Key Features
- Drag-and-drop page builder
- Pre-built templates
- Custom widgets
- Theme customization
- Analytics dashboard

## Support
For help, contact support@kingsbuilder.com
