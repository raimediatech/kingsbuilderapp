// Expose KingsBuilder configuration to client scripts
window.KB_CONFIG = {
  // Change to your production domain if different
  apiBaseUrl: "https://kingsbuilderapp.vercel.app"
};
