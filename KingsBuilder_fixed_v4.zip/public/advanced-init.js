// Advanced KingsBuilder DISABLED
// This file is temporarily disabled to prevent multiple initialization conflicts

console.log('⚠️ Advanced KingsBuilder initialization DISABLED to prevent conflicts');
console.log('✅ Using basic KingsBuilder only for stability');

// The advanced features are now integrated into the main builder
// This prevents the multiple initialization issue that was breaking the UI